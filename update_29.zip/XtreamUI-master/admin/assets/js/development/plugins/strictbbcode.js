/**
 * SCEditor Strict BBCode Plugin
 * http://www.sceditor.com/
 *
 * Copyright (C) 2016, Sam Clarke (samclarke.com)
 *
 * SCEditor is licensed under the MIT license:
 *	http://www.opensource.org/licenses/mit-license.php
 *
 * @author Sam Clarke
 */
// (function (sceditor) {
// 	'use strict';

// 	// var extend = sceditor.utils.extend;

// 	sceditor.plugins.strictbbcode = function () {
// 		// override bbcode plugin add and update default bbcodes to have attrs
// 		// and override their exec funcs
// 	};
// }(sceditor));
