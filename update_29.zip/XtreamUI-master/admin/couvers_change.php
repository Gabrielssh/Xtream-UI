<?php
include "session.php"; include "functions.php";
if ((!$rPermissions["is_admin"]) OR ((!hasPermissions("adv", "add_movie")) && ((!hasPermissions("adv", "edit_movie")) && (!hasPermissions("adv", "series"))))) { exit; }

if (isset($_POST["replace_serie"])) {
	$rOldDNS = ESC(str_replace("", "", $_POST["old_serie"]));
	$rNewDNS = ESC(str_replace("", "", $_POST["new_serie"]));
	$rOldDNS1 = ESC(str_replace("/", "\/", $_POST["old_serie"]));
	$rNewDNS1 = ESC(str_replace("/", "\/", $_POST["new_serie"]));
	$db->query("UPDATE `series` SET `cover` = REPLACE(`cover`, '".$rOldDNS."', '".$rNewDNS."');");
	$db->query("UPDATE `series` SET `backdrop_path` = REPLACE(`backdrop_path`, '".$rOldDNS1."', '".$rNewDNS1."');");
	$db->query("UPDATE `series` SET `seasons` = REPLACE(`seasons`, '".$rOldDNS1."', '".$rNewDNS1."');");
	$_STATUS = 1;	
}
if (isset($_POST["replace_movie"])) {
	$rOldDNS2 = ESC(str_replace("/", "\/", $_POST["old_movie"]));
	$rNewDNS2 = ESC(str_replace("/", "\/", $_POST["new_movie"]));
	$db->query("UPDATE `streams` SET `movie_propeties` = REPLACE(`movie_propeties`, '".$rOldDNS2."', '".$rNewDNS2."');");
	$_STATUS = 1;	
}

if ($rSettings["sidebar"]) {
    include "header_sidebar.php";
} else {
    include "header.php";
}
        if ($rSettings["sidebar"]) { ?>
        <div class="content-page"><div class="content boxed-layout-ext"><div class="container-fluid">
        <?php } else { ?>
        <div class="wrapper boxed-layout-ext"><div class="container-fluid">
        <?php } ?>
                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
									<li>
                                        <a href="./movies.php">
								        <button type="button" class="btn btn-primary waves-effect waves-light btn-sm"><i class="mdi mdi-keyboard-backspace"></i> <?=$_["back_to_tovies"]?></button>
									    </a>	
                                        <a href="./series.php">
								        <button type="button" class="btn btn-primary waves-effect waves-light btn-sm"><i class="mdi mdi-keyboard-backspace"></i> <?=$_["back_to_series"]?></button>
									    </a>	
                                    </li>
                                </ol>
                            </div>
                            <h4 class="page-title"><?=$_["dns_covers_change"]?> </h4>
                        </div>
                    </div>
                </div>     
                <!-- end page title --> 
                <div class="row">
                    <div class="col-xl-12">
                        <?php if ((isset($_STATUS)) && ($_STATUS == 1)) { if (!$rSettings["sucessedit"]) { ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="<?=$_["close"]?>">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <?=$_["the_dns_covers_replacement_was_successful"]?>. 
                        </div>
						<?php } else { ?>
                    <script type="text/javascript">
  					swal("", '<?=$_["the_dns_covers_replacement_was_successful"]?>.', "success");
  					</script>
                        <?php } } ?>
                        <div class="card">
                            <div class="card-body">
								<div id="basicwizard">
									<ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-4">
										<li class="nav-item">
											<a href="#movie-replacement" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> 
												<i class="mdi mdi-file-image mr-1"></i>
												<span class="d-none d-sm-inline"><?=$_["movies_covers_change"]?> </span>
											</a>
										</li>
										<li class="nav-item">
											<a href="#serie-replacement" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> 
												<i class="mdi mdi-file-image mr-1"></i>
												<span class="d-none d-sm-inline"><?=$_["series_covers_change"]?> </span>
											</a>
										</li>
									</ul>
								<div class="tab-content b-0 mb-0 pt-0">
									<div class="tab-pane" id="movie-replacement">
										<form action="./couvers_change.php" method="POST" id="tools_form" data-parsley-validate="">
                                            <div class="row">
                                                <div class="col-12">
												    <p class="sub-header">
                                                        <?=$_["the_dns_covers_change_tool"]?>. 
                                                    </p>
                                                    <div class="form-group row mb-4">
                                                        <label class="col-md-4 col-form-label" for="old_movie"><?=$_["old_dns"]?> </label>
                                                        <div class="col-md-8">
                                                            <input type="text" class="form-control" id="old_movie" name="old_movie" value="" placeholder="http://dns" required data-parsley-trigger="change">
                                                        </div>
                                                    </div>
													<div class="form-group row mb-4">
                                                        <label class="col-md-4 col-form-label" for="new_movie"><?=$_["new_dns"]?> </label>
                                                        <div class="col-md-8">
                                                            <input type="text" class="form-control" id="new_movie" name="new_movie" value="" placeholder="http://dns" required data-parsley-trigger="change">
                                                        </div>
                                                    </div>
                                                </div> <!-- end col -->
                                            </div> <!-- end row -->
                                            <ul class="list-inline wizard mb-0">
												<li class="list-inline-item">
													<div class="custom-control custom-checkbox">
														<input type="checkbox" class="custom-control-input" id="confirmReplace">
														<label class="custom-control-label" for="confirmReplace"><?=$_["i_confirm_that_i_remplace the old_dns"]?>. </label>
													</div>
												</li>
                                                <li class="list-inline-item float-right">
                                                    <input disabled name="replace_movie" id="replace_movie" type="submit" class="btn btn-primary" value="<?=$_["remplace_dns_movies"]?>" />
                                                </li>
                                            </ul>
										</form>
									</div>
									<div class="tab-pane" id="serie-replacement">
										<form action="./couvers_change.php" method="POST" id="tools_form" data-parsley-validate="">
                                            <div class="row">
                                                <div class="col-12">
												    <p class="sub-header">
                                                        <?=$_["the_dns_covers_change_tool"]?>. 
                                                    </p>
                                                    <div class="form-group row mb-4">
                                                        <label class="col-md-4 col-form-label" for="old_serie"><?=$_["old_dns"]?> </label>
                                                        <div class="col-md-8">
                                                            <input type="text" class="form-control" id="old_serie" name="old_serie" value="" placeholder="http://dns" required data-parsley-trigger="change">
                                                        </div>
                                                    </div>
													<div class="form-group row mb-4">
                                                        <label class="col-md-4 col-form-label" for="new_serie"><?=$_["new_dns"]?> </label>
                                                        <div class="col-md-8">
                                                            <input type="text" class="form-control" id="new_serie" name="new_serie" value="" placeholder="http://dns" required data-parsley-trigger="change">
                                                        </div>
                                                    </div>
                                                </div> <!-- end col -->
                                            </div> <!-- end row -->
                                            <ul class="list-inline wizard mb-0">
												<li class="list-inline-item">
													<div class="custom-control custom-checkbox">
														<input type="checkbox" class="custom-control-input" id="confirmReplace1">
														<label class="custom-control-label" for="confirmReplace1"><?=$_["i_confirm_that_i_remplace the old_dns"]?>. </label>
													</div>
												</li>
                                                <li class="list-inline-item float-right">
                                                    <input disabled name="replace_serie" id="replace_serie" type="submit" class="btn btn-primary" value="<?=$_["remplace_dns_series"]?>" />
                                                </li>
                                            </ul>
										</form>
									</div>
								</div>	
								</div> <!-- end #basicwizard-->
                            </div> <!-- end card-body -->
                        </div> <!-- end card-->
                    </div> <!-- end col -->
                </div>
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->
        <?php if ($rAdminSettings["sidebar"]) { echo "</div>"; } ?>
        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 copyright text-center"><?=getFooter()?></div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->

        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/libs/jquery-toast/jquery.toast.min.js"></script>
        <script src="assets/libs/jquery-nice-select/jquery.nice-select.min.js"></script>
        <script src="assets/libs/switchery/switchery.min.js"></script>
        <script src="assets/libs/select2/select2.min.js"></script>
        <script src="assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
        <script src="assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>
        <script src="assets/libs/clockpicker/bootstrap-clockpicker.min.js"></script>
        <script src="assets/libs/moment/moment.min.js"></script>
        <script src="assets/libs/daterangepicker/daterangepicker.js"></script>
        <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/libs/datatables/dataTables.bootstrap4.js"></script>
        <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
        <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/buttons.html5.min.js"></script>
        <script src="assets/libs/datatables/buttons.flash.min.js"></script>
        <script src="assets/libs/datatables/buttons.print.min.js"></script>
        <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
        <script src="assets/libs/datatables/dataTables.select.min.js"></script>
        <script src="assets/libs/parsleyjs/parsley.min.js"></script>
        <script src="assets/libs/twitter-bootstrap-wizard/jquery.bootstrap.wizard.min.js"></script>
        <script src="assets/js/pages/form-wizard.init.js"></script>
        <script src="assets/js/app.min.js"></script>
        
		<script>
        $(document).ready(function() {
			$('select.select').select2({width: '100%'});
            $(window).keypress(function(event){
                if(event.which == 13 && event.target.nodeName != "TEXTAREA") return false;
            });
			$("#confirmReplace").change(function() {
				if ($(this).is(":checked")) {
					$("#replace_movie").attr("disabled", false);
				} else {
					$("#replace_movie").attr("disabled", true);
				}
			});
			$("#confirmReplace1").change(function() {
				if ($(this).is(":checked")) {
					$("#replace_serie").attr("disabled", false);
				} else {
					$("#replace_serie").attr("disabled", true);
				}
			});
            $("form").attr('autocomplete', 'off');
        });
        </script>
    </body>
</html>